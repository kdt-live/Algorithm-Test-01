input_ = input().split()
a = int(input_[0])
b = int(input_[1])
res = abs(a - b) + 1
print(res)